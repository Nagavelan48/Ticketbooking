package com.booking.globalExceptionHandling;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import com.booking.exception.ExistException;
import com.booking.exception.GmailException;
import com.booking.exception.InvalidPasswordException;
import com.booking.exception.InvalidUserException;
import com.booking.exception.PasswordException;

@RestControllerAdvice
public class ExceptionHandlingClass {  
	@ExceptionHandler
	public ResponseEntity<Object>gmailHandle(GmailException sue){
		return new ResponseEntity<Object>("Invalid Mail Id",HttpStatus.BAD_REQUEST);
	}
	
	@ExceptionHandler
	public ResponseEntity<Object>passwordHandle(PasswordException sue){
		return new ResponseEntity<Object>("Password must be more than 8 Characters",HttpStatus.BAD_REQUEST);
	}
	@ExceptionHandler
	public ResponseEntity<Object> existHandle(ExistException sue){
		return new ResponseEntity<Object>("Already exist please login",HttpStatus.BAD_REQUEST);
	}
	
	@ExceptionHandler
	public ResponseEntity<Object> InvalidHandle(InvalidUserException sue){
		return new ResponseEntity<Object>("Please Sign up",HttpStatus.BAD_REQUEST);
	}
	
	@ExceptionHandler
	public ResponseEntity<Object> InvalidPasswordHandle(InvalidPasswordException sue){
		return new ResponseEntity<Object>("Incorrect Password",HttpStatus.BAD_REQUEST);
	}

}
