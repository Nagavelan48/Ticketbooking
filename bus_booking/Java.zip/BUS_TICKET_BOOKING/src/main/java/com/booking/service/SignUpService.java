package com.booking.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.booking.dao.SignUpDao;
import com.booking.entity.SignUp;
import com.booking.exception.ExistException;
import com.booking.exception.GmailException;
import com.booking.exception.PasswordException;

@Service
public class SignUpService {
	
	@Autowired
	SignUpDao signUpDao;

	public String signUp(SignUp signup) throws Exception{
		if(signup.getMail().contains("@gmail.com") && (signup.getPass().length()>=8)){
			List<SignUp> x =  getSignUpLog();
			int count =0;
			for(SignUp s : x) {
				if(s.getMail().equals(signup.getMail()) ) {
					count++;
				}
			}
			if(count==0) {
				return signUpDao.signUp(signup);
			}
			else {
				
				throw new ExistException("Already Exist");
			}
		}
		else if(!signup.getMail().contains("@gmail.com")) {
			throw new GmailException("Invalid Mail Id");
		}
		else {
			throw new PasswordException("Password must be more than 8 characters");
		}
	}

	public List<SignUp> getSignUpLog() {
		// TODO Auto-generated method stub
		return signUpDao.getSignUpLog();
	}

	
	
}
