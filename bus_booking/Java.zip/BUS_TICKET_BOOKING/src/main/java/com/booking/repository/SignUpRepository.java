package com.booking.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.booking.entity.SignUp;

public interface SignUpRepository extends JpaRepository<SignUp, String> {

}

