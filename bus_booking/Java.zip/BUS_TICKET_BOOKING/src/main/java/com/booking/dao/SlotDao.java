package com.booking.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.booking.entity.Slot;
import com.booking.repository.SlotRepository;
@Repository
public class SlotDao {
	
	
	@Autowired 
	SlotRepository sr;
	public String slot(Slot slot) {
		sr.save(slot);
		return "Success";
	}
	public List<Slot> getbook() {
		// TODO Auto-generated method stub
		return sr.findAll();
	}
	public Slot updateSlotUpdate(Slot slotUpdate) {
		// TODO Auto-generated method stub
		return sr.save(slotUpdate);
	}
	
//	public Slot findBysno(int busId) {
//		return sr.findBysno(busId);
//	}
	
	

}
