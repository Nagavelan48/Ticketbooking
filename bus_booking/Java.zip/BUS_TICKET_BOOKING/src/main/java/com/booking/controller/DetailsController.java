package com.booking.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.booking.entity.Details;

import com.booking.service.DetailsService;

@CrossOrigin(origins = "http://127.0.0.1:5500")
@RestController
@RequestMapping("/details")
public class DetailsController {
		
	@Autowired
	DetailsService ds;
	
	@PostMapping("/detail")
	public String detail(@RequestBody Details detail) {
		return ds.detail(detail);
	}
	
	@GetMapping("/getdetail")
	public List<Details> getDetails(){
		return ds.getDetails();
	}
	
	@GetMapping("/getByMail/{email}")
	public Details getByMail (@PathVariable String email) {
		Details d = null;
		for(Details de: getDetails()) {
			if(de.getEid().equalsIgnoreCase(email)) {
				d = de;
			}
		}
		return d; 
	}
	
	
	
}
