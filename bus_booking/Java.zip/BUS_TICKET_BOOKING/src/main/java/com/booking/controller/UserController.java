package com.booking.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


import com.booking.entity.UserEntity;
import com.booking.service.UserService;

@CrossOrigin(origins = "http://127.0.0.1:5500")
@RestController
@RequestMapping("/user")
public class UserController {
	 @Autowired
	 UserService us;
	 
	 @PostMapping("/user1")
	 public String user(@RequestBody UserEntity user) {
//		 System.out.println(user.getAdult() + " " + user.getChild() + " " + user.getFrom()  + " " + user.getTo());
		return us.user(user);
	 }
//	 @GetMapping("/user2")
//	 public List<>
	 @GetMapping("/getUserLog")
		public List<UserEntity> getSignUpLog(){
			return us.getUserLog();
		}
}
