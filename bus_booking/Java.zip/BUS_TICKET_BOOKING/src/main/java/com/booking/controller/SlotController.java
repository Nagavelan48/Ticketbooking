package com.booking.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.booking.entity.Slot;

import com.booking.service.SlotService;

@CrossOrigin(origins = "http://127.0.0.1:5500")
@RestController
@RequestMapping("/slot")
public class SlotController {

	@Autowired
	SlotService ss;
	
	@PostMapping("/book")
	public String slot(@RequestBody Slot slot) {
		return ss.slot(slot);
		
	}


@GetMapping("/getbook")
public List<Slot> getbook(){
	return ss.getbook();
}

@PutMapping("/update")
public Slot updateSlotUpdate(@RequestBody Slot slotUpdate) {
	return ss.updateSlotUpdate(slotUpdate);
}

//public Slot findBysno(int busId) {
//	return ss.findBysno(busI);
//}
}