package com.booking.controller;

import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.booking.service.LoginService;
import com.booking.entity.Login;
import com.booking.exception.InvalidPasswordException;
import com.booking.exception.InvalidUserException;
@CrossOrigin(origins = "http://127.0.0.1:5500")
@RestController
@RequestMapping("/Login")
public class LoginController {
	@Autowired
	LoginService ls;
	 


	
	@PostMapping("/Login")
	public String Login(@RequestBody Login signEntry) throws InvalidUserException, InvalidPasswordException {
		System.out.println(signEntry.getEmail() + " " + signEntry.getPassword());
		return ls.Login(signEntry); 
	}
	
	@GetMapping("/getLogInList")
	public List<Login> getLogList(){
		return ls.getLogList();
	}
	


}
