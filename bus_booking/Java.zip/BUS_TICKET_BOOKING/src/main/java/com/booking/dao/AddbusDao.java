package com.booking.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.booking.entity.Addbus;
import com.booking.repository.AddbusRepository;
@Repository
public class AddbusDao {
	
	
	@Autowired
	AddbusRepository abr;
	public String addbus(Addbus addbus) {
		abr.save(addbus);
		return "Success";
	}
	public List<Addbus> getAdduser() {
		// TODO Auto-generated method stub
		return abr.findAll();
	}

}
