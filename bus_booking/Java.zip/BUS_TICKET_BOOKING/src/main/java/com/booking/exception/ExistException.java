package com.booking.exception;

public class ExistException extends Exception {
	public ExistException(String msg) {
		super(msg);
	}
}
