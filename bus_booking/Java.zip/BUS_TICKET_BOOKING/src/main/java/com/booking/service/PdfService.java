//package com.booking.service;
//
//import java.io.ByteArrayOutputStream;
//import java.util.List;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.stereotype.Service;
//
//import com.itextpdf.kernel.pdf.PdfDocument;
//import com.itextpdf.kernel.pdf.PdfWriter;
//import com.itextpdf.layout.Document;
//import com.itextpdf.layout.element.Cell;
//import com.itextpdf.layout.element.Paragraph;
//
//import jakarta.persistence.Table;
//
//@Service
//public class PdfService {
////    public byte[] generatePdf(List<AvailableColleges> colleges) {
////        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
//// 
////        PdfWriter writer = new PdfWriter(byteArrayOutputStream);
////        PdfDocument pdf = new PdfDocument(writer);
////        Document document = new Document(pdf);
//// 
////        // Create a table with 2 columns
////        Table table = new Table(new float[]{1, 2});
////        table.addCell(new Cell().add(new Paragraph("Code")));
////        table.addCell(new Cell().add(new Paragraph("Name")));
//// 
////        // Fill table with college data
////        for (AvailableColleges college : colleges) {
////            table.addCell(new Cell().add(new Paragraph(college.getCode())));
////            table.addCell(new Cell().add(new Paragraph(college.getName())));
////        }
//// 
////        document.add(table);
////        document.close();
//// 
////        return byteArrayOutputStream.toByteArray();
////    }
//}