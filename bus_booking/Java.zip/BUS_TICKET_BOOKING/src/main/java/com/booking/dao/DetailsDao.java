package com.booking.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.booking.entity.Details;
import com.booking.entity.Slot;
import com.booking.repository.DetailsRepository;
@Repository
public class DetailsDao {
		
	
		@Autowired
		DetailsRepository dr;
	public String detail(Details detail) {
		dr.save(detail);
		return "Success";
	}
	public List<Details> getDetails() {
		
		return dr.findAll();
	}
	
	

}
