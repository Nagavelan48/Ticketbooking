package com.booking.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.booking.entity.SignUp;
import com.booking.repository.SignUpRepository;

@Repository
public class SignUpDao {
	
	@Autowired
	SignUpRepository signUpRepo;

	public String signUp(SignUp signup) {
		signUpRepo.save(signup);
		return "Success";
	}

	public List<SignUp> getSignUpLog() {
		// TODO Auto-generated method stub
		return signUpRepo.findAll();
	}
	
	
	
	
}
