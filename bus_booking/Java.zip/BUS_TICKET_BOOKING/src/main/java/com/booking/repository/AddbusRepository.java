package com.booking.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.booking.entity.Addbus;

public interface AddbusRepository extends JpaRepository<Addbus,Integer>{

}
