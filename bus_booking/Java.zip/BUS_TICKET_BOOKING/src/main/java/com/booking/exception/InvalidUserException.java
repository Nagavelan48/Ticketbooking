package com.booking.exception;

public class InvalidUserException extends Exception{
	public InvalidUserException(String msg) {
		super(msg);
	}

}
