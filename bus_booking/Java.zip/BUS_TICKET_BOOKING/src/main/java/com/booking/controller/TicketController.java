package com.booking.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.booking.entity.Details;
import com.booking.entity.Ticket;
import com.booking.service.EmailService;
import com.booking.service.TicketService;

import jakarta.mail.MessagingException;

@CrossOrigin(origins = "http://127.0.0.1:5500")
@RestController
@RequestMapping("/ticket")
public class TicketController {
	
	@Autowired
	EmailService emailService;
	
	@Autowired
	TicketService ts;
	
	@PostMapping("/tickets")
	public String ticket(@RequestBody Ticket ticket) {
		sendConirmation(ticket);
		return ts.ticket(ticket);
}
	
	@GetMapping("/getticket")
	public List<Ticket> getticket(){
		return ts.getticket();
	}
	
	@DeleteMapping("/deletebook/{sno}")
	public String deleteBooking(@PathVariable int sno) {
		return ts.deleteBooking(sno);
	}
	
	@GetMapping("/getticketByDate/{date}")
	public List<Ticket> getTicketByDate(@PathVariable String d) {
		System.out.println(d);
		return ts.getTicketByDate(d);
	}
	
	@PostMapping("/send-document/{email}")
    public ResponseEntity<String> sendConirmation(Ticket t) {
        try {
            // Ensure Details object is not null
        	
        	
        	
        	
            if (t != null) {
               
                String res = "Hi " + t.getUsername() + "\n The seat Number u booked is " + t.getSn() + "\n A passenger List is " + t.getPl() + "\n Start " + t.getSp() + " " + "at " + t.getSt() + "\n End " + t.getEp() + " "+"at " + t.getEt();
                emailService.sendEmailWithAttachment(t.getEmail(), " ", " " + res , res.getBytes());
                return ResponseEntity.ok("Email sent successfully.");
            } else {
                return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Details object is null");
            }
        } catch (MessagingException e) {
            e.printStackTrace();
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Failed to send email");
        }
    }
	
}

