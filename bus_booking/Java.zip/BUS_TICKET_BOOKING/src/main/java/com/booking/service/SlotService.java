package com.booking.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.booking.dao.SlotDao;
import com.booking.entity.Slot;
@Service
public class SlotService {
	
	
	@Autowired
	SlotDao sd;
	public String slot(Slot slot) {
		
		return sd.slot(slot);
	}
	public List<Slot> getbook() {
		
		return sd.getbook();
	}
	public Slot updateSlotUpdate(Slot slotUpdate) {
		// TODO Auto-generated method stub
		return sd.updateSlotUpdate(slotUpdate);
	}
	
//	public Slot findBysno(int busId) {
//		// TODO Auto-generated method stub
//		return sd.findBysno(busId);
//	}

}
