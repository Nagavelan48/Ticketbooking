package com.booking.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.booking.entity.Details;

public interface DetailsRepository extends JpaRepository<Details,Integer>{

}
