package com.booking.service;



import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.booking.controller.SlotController;
import com.booking.dao.DetailsDao;
import com.booking.entity.Details;
import com.booking.entity.Slot;

@Service
public class DetailsService {
    
    @Autowired
    DetailsDao dd;
    
    @Autowired
    SlotController sc;
    
    public String detail(Details detail) {
        
        try {
            String result = dd.detail(detail);
            if ("Success".equals(result)) {
                List<Slot> slots = sc.getbook();
                
                for (Slot s : slots) {
                	System.out.println(s.getBusId());
                	System.out.println(s.getDate11());
                	System.out.println(s.getFrom1());
                	System.out.println(s.getTo1());
                	System.out.println(s.getSeatnumbers());
                	System.out.println(detail.getInputBox());
                	System.out.println(detail.getDate1());
                	System.out.println(detail.getDrop1());
                	System.out.println(detail.getPickup());
                	System.out.println(detail.getSn());
                	
                    if ((s.getBusId() == detail.getInputBox()) &&( s.getDate11().equals(detail.getDate1()) )&&
                            (s.getFrom1().equals(detail.getPickup())) && (s.getTo1().equals(detail.getDrop1())) &&
                           ( s.getSeatnumbers().equals(detail.getSn()))) {
                    	System.out.println("Reached");
                        s.setBooked(1);
                        sc.updateSlotUpdate(s);
                        return "Booking added successfully";
                    }
                }
            } else {
                return "Failed to add booking";
            }
        } catch (Exception e) {
            return "Error adding booking";
        }
        return null;
    }

    public List<Details> getDetails() {
        return dd.getDetails();
    }
}
