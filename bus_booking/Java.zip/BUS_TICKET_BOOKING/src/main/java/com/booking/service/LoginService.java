package com.booking.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.booking.dao.LoginDao;
import com.booking.entity.Login;
import com.booking.entity.SignUp;
import com.booking.exception.InvalidPasswordException;
import com.booking.exception.InvalidUserException;

@Service
public class LoginService {
	@Autowired
	LoginDao ld;

	@Autowired
	SignUpService sus;

	public String Login(Login signEntry) throws InvalidUserException, InvalidPasswordException {
		signEntry.setCount(1);

		List<SignUp> a = sus.getSignUpLog();
		List<Login> y = getLogList(); 

		y.forEach(x -> System.out.println(x.getEmail() + " " + x.getPassword() + " " + x.getCount()));
		boolean flag = true;
		boolean flag2 = true;
		for (int i = 0; i < a.size(); i++) {
			if (signEntry.getEmail().equals(a.get(i).getMail())
					&& signEntry.getPassword().equals(a.get(i).getPass())) {
				flag = true;
				for (Login si : y) {
					if (si.getEmail().equals(signEntry.getEmail())
							&& si.getPassword().equals(signEntry.getPassword())) {
						si.setCount(si.getCount() + 1);
						return ld.Login(si);
					}
				}
				return ld.Login(signEntry);
			} 
			else if(signEntry.getEmail().equals(a.get(i).getMail()) && !signEntry.getPassword().equals(a.get(i).getPass())) {
				flag2 = false;
			}
			else {
				flag = false;
			}
		}
		if(flag2 == false) {
			throw new InvalidPasswordException("Incorrect Password");
		}
		if (flag == false) {
			throw new InvalidUserException("Please sign up");
		}

		return ld.Login(signEntry);

	}

	public List<Login> getLogList() {

		return ld.getLogList();
	}
}
