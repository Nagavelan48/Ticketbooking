package com.booking.exception;

public class GmailException extends Exception {
	public GmailException(String msg) {
		super(msg);
	}

}
