package com.booking.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.booking.entity.Ticket;
import com.booking.repository.TicketRepository;
@Repository
public class TicketDao {
		
	
	@Autowired
	TicketRepository tr;
	public String ticket(Ticket ticket) {
		tr.save(ticket);
		return "Success";
	}
	public List<Ticket> getticket() {
		
		return tr.findAll();
	}
	public String deleteBooking(int sno) {
		tr.deleteById(sno);
		return "Deleted";
	}

}
