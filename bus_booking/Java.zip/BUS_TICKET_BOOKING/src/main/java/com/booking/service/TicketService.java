package com.booking.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.booking.dao.TicketDao;
import com.booking.entity.Ticket;
@Service
public class TicketService {
		
	
	@Autowired
	TicketDao td;
	public String ticket(Ticket ticket) {
		// TODO Auto-generated method stub
		return td.ticket(ticket);
	}
	public List<Ticket> getticket() {
		
		return td.getticket();
	}
	
	public String deleteBooking(int sno) {
		// TODO Auto-generated method stub
		return td.deleteBooking(sno);
	}
	public List<Ticket> getTicketByDate(String d) {
		// TODO Auto-generated method stub
		return getticket().stream().filter(x->x.getDate3().equalsIgnoreCase(d)).toList();
	}

}
