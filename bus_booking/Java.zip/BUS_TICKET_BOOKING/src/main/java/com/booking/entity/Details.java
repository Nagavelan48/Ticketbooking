package com.booking.entity;

import org.springframework.stereotype.Component;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Component
@Table(name="details")
public class Details {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int sno;
	private String date1;
	private String pickup;
	private String st;
	private String uname;
	private String drop1;
	private String et;
	private int inputBox;
	private String sn;
	private String passengers;
	private String age;
	private String gen;
	private long ac;
	private long mn;
	private String eid;
	private int sumTextField;
	public int getSumTextField() {
		return sumTextField;
	}
	public void setSumTextField(int sumTextField) {
		this.sumTextField = sumTextField;
	}
	public int getSno() {
		return sno;
	}
	public void setSno(int sno) {
		this.sno = sno;
	}
	
	public String getPickup() {
		return pickup;
	}
	public void setPickup(String pickup) {
		this.pickup = pickup;
	}
	public String getSt() {
		return st;
	}
	public void setSt(String st) {
		this.st = st;
	}
	public String getUname() {
		return uname;
	}
	public void setUname(String uname) {
		this.uname = uname;
	}
	
	public String getDate1() {
		return date1;
	}
	public void setDate1(String date1) {
		this.date1 = date1;
	}
	public String getDrop1() {
		return drop1;
	}
	public void setDrop1(String drop1) {
		this.drop1 = drop1;
	}
	public String getEt() {
		return et;
	}
	public void setEt(String et) {
		this.et = et;
	}
	public int getInputBox() {
		return inputBox;
	}
	public void setInputBox(int inputBox) {
		this.inputBox = inputBox;
	}
	public String getSn() {
		return sn;
	}
	public void setSn(String sn) {
		this.sn = sn;
	}
	public String getPassengers() {
		return passengers;
	}
	public void setPassengers(String passengers) {
		this.passengers = passengers;
	}
	
	public String getAge() {
		return age;
	}
	public void setAge(String age) {
		this.age = age;
	}

	
	public String getGen() {
		return gen;
	}
	public void setGen(String gen) {
		this.gen = gen;
	}
	public long getAc() {
		return ac;
	}
	public void setAc(long ac) {
		this.ac = ac;
	}
	public long getMn() {
		return mn;
	}
	public void setMn(long mn) {
		this.mn = mn;
	}
	public String getEid() {
		return eid;
	}
	public void setEid(String eid) {
		this.eid = eid;
	}
}
