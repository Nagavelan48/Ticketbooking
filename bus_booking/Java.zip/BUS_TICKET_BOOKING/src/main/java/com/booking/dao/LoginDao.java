package com.booking.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.booking.entity.Login;
import com.booking.repository.LoginRepository;

@Repository
public class LoginDao {
	@Autowired
	LoginRepository lir;

	public String Login(Login signEntry) {
		System.out.println(signEntry.getCount());
		lir.save(signEntry);

		return "Valid Person";
	}

	public List<Login> getLogList() {

		return lir.findAll();
	}

}
