package com.booking.exception;

public class PasswordException extends Exception{
	public PasswordException(String msg) {
		super(msg);
	}

}
