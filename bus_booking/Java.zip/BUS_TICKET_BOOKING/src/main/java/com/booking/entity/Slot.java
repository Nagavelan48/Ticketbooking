package com.booking.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "slot")
public class Slot {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int sno;
	private int busId;
	private String date11;
	private String from1;
	private String to1;
	private String seatnumbers;
	private int booked;
	public int getSno() {
		return sno;
	}
	public void setSno(int sno) {
		this.sno = sno;
	}
	public int getBusId() {
		return busId;
	}
	public void setBusId(int busId) {
		this.busId = busId;
	}
	public String getDate11() {
		return date11;
	}
	public void setDate11(String date11) {
		this.date11 = date11;
	}
	public String getFrom1() {
		return from1;
	}
	public void setFrom1(String from1) {
		this.from1 = from1;
	}
	public String getTo1() {
		return to1;
	}
	public void setTo1(String to1) {
		this.to1 = to1;
	}
	public String getSeatnumbers() {
		return seatnumbers;
	}
	public void setSeatnumbers(String seatnumbers) {
		this.seatnumbers = seatnumbers;
	}
	public int getBooked() {
		return booked;
	}
	public void setBooked(int booked) {
		this.booked = booked;
	}
	@Override
	public String toString() {
		return "Slot [sno=" + sno + ", busId=" + busId + ", date11=" + date11 + ", from1=" + from1 + ", to1=" + to1
				+ ", seatnumbers=" + seatnumbers + ", booked=" + booked + "]";
	}
	
	
	
	
}
