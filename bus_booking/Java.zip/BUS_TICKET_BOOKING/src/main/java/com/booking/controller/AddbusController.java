package com.booking.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.booking.entity.Addbus;

import com.booking.service.AddbusService;


@CrossOrigin(origins = "http://127.0.0.1:5500")
@RestController
@RequestMapping("/addbus")
public class AddbusController {
		
	@Autowired
	AddbusService abs;
	 
	
	@PostMapping("/addbus1")
	public String adddbus(@RequestBody Addbus addbus) {
		return abs.addbus(addbus);
}
	@GetMapping("/getAdduser")
	public List<Addbus> getAdduser(){
		return abs.getAdduser();
	}
	}
