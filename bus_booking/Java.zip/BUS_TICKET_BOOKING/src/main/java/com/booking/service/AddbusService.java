package com.booking.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.booking.dao.AddbusDao;
import com.booking.entity.Addbus;
@Service
public class AddbusService {
	
	
	@Autowired
	AddbusDao abd;
	public String addbus(Addbus addbus) {
		// TODO Auto-generated method stub
		return abd.addbus(addbus);
	}
	public List<Addbus> getAdduser() {
		// TODO Auto-generated method stub
		return abd.getAdduser();
	}

}
