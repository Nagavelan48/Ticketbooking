package com.booking.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.booking.dao.FeedbackDao;
import com.booking.entity.Feedback;


@Service
public class FeedbackService {
	
	@Autowired
	FeedbackDao fd;

	public String feedback(Feedback feedback) {
		
		return fd.feedback(feedback);
	}

	public List<Feedback> getfeedback() {
		return fd.getfeedback();
	}

}
