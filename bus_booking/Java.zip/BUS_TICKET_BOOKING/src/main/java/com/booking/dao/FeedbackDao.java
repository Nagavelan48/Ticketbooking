package com.booking.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.booking.entity.Feedback;
import com.booking.repository.FeedbackRepository;



@Repository
public class FeedbackDao {
	
	
	@Autowired
	FeedbackRepository fr;

	public String feedback(Feedback feedback) {
		fr.save(feedback);
		return "Success";
	}

	public List<Feedback> getfeedback() {
		
		return fr.findAll();
	}
	
	

}
