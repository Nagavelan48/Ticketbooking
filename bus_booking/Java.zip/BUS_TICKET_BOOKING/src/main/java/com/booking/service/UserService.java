package com.booking.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.booking.dao.UserDao;

import com.booking.entity.UserEntity;
@Service
public class UserService {

	@Autowired
	UserDao  ud;

	public String user(UserEntity user) {
		
		return ud.user(user);
	}

	public List<UserEntity> getUserLog() {
		// TODO Auto-generated method stub
		return ud.getUserLog();
	}

}
