package com.booking.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;


import com.booking.entity.UserEntity;
import com.booking.repository.UserRepository;
@Repository
public class UserDao {
	@Autowired
	UserRepository ur;
	public String user(UserEntity user) {
		ur.save(user);
		return "Success";
	}
	public List<UserEntity> getUserLog() {
		// TODO Auto-generated method stub
		return ur.findAll();
	}

}
