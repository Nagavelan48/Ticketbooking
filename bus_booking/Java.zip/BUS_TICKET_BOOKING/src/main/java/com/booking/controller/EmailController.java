package com.booking.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.booking.entity.Details;
import com.booking.service.EmailService;

import jakarta.mail.MessagingException;

@CrossOrigin(origins = "http://127.0.0.1:5500")
@RestController
@RequestMapping("/email")
public class EmailController {

    @Autowired
    private EmailService emailService;

    @Autowired
    private DetailsController details; // Make sure Details object is properly injected

    @PostMapping("/send-document/{email}")
    public ResponseEntity<String> sendDocument(@PathVariable String email) {
        try {
            // Ensure Details object is not null
        	
        	Details det = details.getByMail(email);
        	System.out.println(det.getEid() + " " + det.getMn());
        	
        	
            if (details != null) {
               
                String name = "Hi " + det.getUname() + "!\nKindly verify your mobile number " + det.getMn();
                System.out.println(name +" " + det.getMn());
                emailService.sendEmailWithAttachment(email, " ", " " + name , name.getBytes());
                return ResponseEntity.ok("Email sent successfully.");
            } else {
                return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Details object is null");
            }
        } catch (MessagingException e) {
            e.printStackTrace();
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Failed to send email");
        }
    }
    
    
    
    
//    @PostMapping("/send-document/{email}")
//    public ResponseEntity<String> sendDocument(@PathVariable String email) {
//        try {
//            // Ensure Details object is not null
//        	
//        	Details det = details.getByMail(email);
//        	System.out.println(det.getEid() + " " + det.getMn());
//        	
//        	
//            if (details != null) {
//               
//                String name = "Hi " + det.getUname() + "!\nKindly verify your mobile number " + det.getMn();
//                System.out.println(name +" " + det.getMn());
//                emailService.sendEmailWithAttachment(email, " ", " " + name , name.getBytes());
//                return ResponseEntity.ok("Email sent successfully.");
//            } else {
//                return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Details object is null");
//            }
//        } catch (MessagingException e) {
//            e.printStackTrace();
//            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Failed to send email");
//        }
//    }
}


